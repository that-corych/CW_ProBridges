﻿using Sia.CW.OverallLibrary.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CW.ProBridges.ViewModelLayer.ViewModel
{
    public class MainWindowViewModel : ViewModelBase
    {
        private Employee _employeeModel;
        public Employee EmployeeModel
        {
            get => _employeeModel;
            set
            {
                _employeeModel = value;
                OnPropertyChanged("EmployeeModel");
            }
        }

        public bool Login()
        {
            bool ret = false;
            if (ErrorMessage())
            {
                if (ValidateCredentials())
                {
                    Close(false);
                    ret = true;
                }
            }

            return ret;
        }
    }
}
