﻿using CW.ProBridges.ViewModelLayer.ViewModel;
using Sia.CW.OverallLibrary.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace CW.ProBridges.ViewModelLayer.ViewModel
{
    public class SplashScreenViewModel : ViewModelBase
    {
        private const int SECONDS = 4000;

        private string _splashScreenInfoTitle = string.Empty;

        public string SplashScreenInfoTitle
        {
            get => _splashScreenInfoTitle; 
            set
            {
                _splashScreenInfoTitle = value;
                OnPropertyChanged();
            }
        }

        public void FirstMessage()
        {
            Thread.Sleep(SECONDS);
        }
        public void SecondMessage()
        {
            Thread.Sleep(SECONDS);
        }
        public void ThirdMessage()
        {
            Thread.Sleep(SECONDS);
        }
        public void ClearSplashScreenInfoTitle()
        {
            SplashScreenInfoTitle = string.Empty;
        }
    }
}
